<?php
// Include necessary files and start the session
session_start();
include './include/connection.php';

// Get the question from the POST data
$question = $_POST['question'] ?? '';

// Load FAQ data
$faqData = json_decode(file_get_contents('faq.json'), true)['faq'];

// Find the answer in the FAQ data
$answer = "I'm sorry, I don't have a specific answer for that question. Can you please rephrase or ask something else?";

foreach ($faqData as $faqItem) {
    if (strtolower($faqItem['question']) === strtolower($question)) {
        $answer = $faqItem['answer'];
        break;
    }
}

// Return the answer as JSON
header('Content-Type: application/json');
echo json_encode(['answer' => $answer]);
?>