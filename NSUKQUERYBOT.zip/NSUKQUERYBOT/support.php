<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Help & Support - NSUK</title>
    <link href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap/5.3.0/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css" rel="stylesheet">
    <style>
    body {
        font-family: 'Poppins', sans-serif;
        background-color: #f9f9f9;
    }

    .support-header {
        background: linear-gradient(135deg, #006666, #008080);
        color: white;
        padding: 50px 0;
        text-align: center;
    }

    .support-header h1 {
        font-weight: 700;
        letter-spacing: 1px;
    }

    .support-content {
        padding: 40px;
    }

    .faq-section {
        margin-top: 30px;
    }

    .faq-title {
        font-size: 22px;
        font-weight: 600;
        margin-bottom: 20px;
    }

    .faq-item {
        margin-bottom: 10px;
        border: 1px solid #ddd;
        padding: 20px;
        border-radius: 8px;
        background-color: #fff;
        transition: background-color 0.3s;
    }

    .faq-item:hover {
        background-color: #f0f0f0;
    }

    .contact-section {
        margin-top: 50px;
    }

    .contact-title {
        font-size: 24px;
        font-weight: 700;
        margin-bottom: 20px;
    }

    .contact-card {
        background-color: #fff;
        padding: 20px;
        border: 1px solid #ddd;
        border-radius: 8px;
        margin-bottom: 20px;
    }

    .contact-card h5 {
        font-weight: 600;
    }

    .contact-card a {
        color: #006666;
        text-decoration: none;
    }

    .contact-card a:hover {
        text-decoration: underline;
    }
    </style>
</head>

<body>
    <div class="support-header">
        <div class="container">
            <h1>Help & Support</h1>
            <p>Your resource center for all questions and support at NSUK.</p>
            <a href="index.php">
                <div class="btn btn-success">Back to bot
                </div>
            </a>
        </div>
    </div>

    <div class="support-content container">
        <!-- FAQ Section -->
        <div class="faq-section">
            <div class="faq-title">Frequently Asked Questions</div>

            <div class="faq-item">
                <h5>How can I access the student portal?</h5>
                <p>Students can access the portal via the official NSUK portal <a
                        href="https://ug.nsuk.edu.ng">here</a>. The portal allows you to register for courses,
                    check
                    results, and manage your student account.</p>
            </div>

            <div class="faq-item">
                <h5>What are the admission requirements?</h5>
                <p>For undergraduate programs, prospective students must have at least 5 credits in SSCE or NECO,
                    including English and Mathematics. You can find full details on the <a
                        href="https://nsuk.edu.ng">official page</a>.</p>
            </div>
            <div class=" faq-item">
                <h5>Where can I pay my school fees?</h5>
                <p>School fees can be paid online through the student portal or at any designated bank listed by
                    h NSUK.
                    Be sure to keep your receipt for verification purposes.</p>
            </div>

            <div class="faq-item">
                <h5>How do I contact NSUK’s ICT department for support?</h5>
                <p>NSUK’s ICT department can be reached via email at <a
                        href="mailto:ictsupport@nsuk.edu.ng">ictsupport@nsuk.edu.ng</a>. They provide assistance
                    with
                    portal access, network issues, and more.</p>
            </div>
        </div>

        <!-- Contact Information Section -->
        <div class="contact-section">
            <div class="contact-title">Contact Us</div>

            <div class="contact-card">
                <h5>Admissions Office</h5>
                <p>If you have queries regarding admissions, contact us:</p>
                <p>Email: <a href="mailto:admissions@nsuk.edu.ng">admissions@nsuk.edu.ng</a><br>Phone: +234 814 123
                    4567
                </p>
            </div>

            <div class="contact-card">
                <h5>ICT Support</h5>
                <p>For any technical assistance, reach out to:</p>
                <p>Email: <a href="mailto:ictsupport@nsuk.edu.ng">ictsupport@nsuk.edu.ng</a><br>Phone: +234 813 987
                    6543
                </p>
            </div>

            <div class="contact-card">
                <h5>Student Affairs</h5>
                <p>Need help with student-related services? Contact:</p>
                <p>Email: <a href="mailto:studentaffairs@nsuk.edu.ng">studentaffairs@nsuk.edu.ng</a><br>Phone: +234
                    812
                    345 6789</p>
            </div>

        </div>
    </div>

    <script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap/5.3.0/js/bootstrap.bundle.min.js"></script>
</body>

</html>