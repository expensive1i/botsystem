<?php
// chatgpt_api.php

// Enable error reporting for debugging (remove in production)
error_reporting(E_ALL);
ini_set('display_errors', 1);

// Set your OpenAI API key here
// $api_key = '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';
$api_key = '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';


// Get the message from the POST request
$message = $_POST['message'] ?? '';

if (empty($message)) {
    echo json_encode(['error' => 'No message provided']);
    exit;
}

// Prepare the data for the API request
$data = [
    'model' => 'gpt-3.5-turbo',
    'messages' => [
        ['role' => 'system', 'content' => 'You are a helpful assistant for NSUK students.'],
        ['role' => 'user', 'content' => $message]
    ],
    'max_tokens' => 150
];

// Initialize cURL session
$ch = curl_init('https://api.openai.com/v1/chat/completions');

// Set cURL options
curl_setopt_array($ch, [
    CURLOPT_RETURNTRANSFER => true,
    CURLOPT_POST => true,
    CURLOPT_POSTFIELDS => json_encode($data),
    CURLOPT_HTTPHEADER => [
        'Content-Type: application/json',
        'Authorization: Bearer ' . $api_key
    ],
    CURLOPT_SSL_VERIFYPEER => true,
    CURLOPT_SSL_VERIFYHOST => 2,
]);

// Execute the cURL request
$response = curl_exec($ch);

// Check for cURL errors
if (curl_errno($ch)) {
    echo json_encode(['error' => 'cURL error: ' . curl_error($ch)]);
    exit;
}

// Get the HTTP status code
$http_code = curl_getinfo($ch, CURLINFO_HTTP_CODE);

// Close cURL session
curl_close($ch);

// Decode the JSON response
$result = json_decode($response, true);

// Check for HTTP errors
if ($http_code !== 200) {
    $error_message = $result['error']['message'] ?? 'Unknown error';
    echo json_encode(['error' => "HTTP error $http_code: $error_message"]);
    exit;
}

// Check for API errors
if (isset($result['error'])) {
    echo json_encode(['error' => 'API error: ' . $result['error']['message']]);
    exit;
}

// Extract the bot's response
$botResponse = $result['choices'][0]['message']['content'] ?? 'Sorry, I couldn\'t generate a response.';

// Send the response back to the client
echo json_encode(['response' => $botResponse]);