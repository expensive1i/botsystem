<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>NSUKQUERYBOT</title>
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
    .chat-container {
        max-width: 800px;
        margin: 20px auto;
        border: 1px solid #ddd;
        border-radius: 5px;
        overflow: hidden;
    }

    .chat-header {
        background-color: #007bff;
        color: white;
        padding: 10px;
        text-align: center;
    }

    .chat-messages {
        height: 400px;
        overflow-y: auto;
        padding: 10px;
    }

    .message {
        margin-bottom: 10px;
        padding: 10px;
        border-radius: 5px;
    }

    .user-message {
        background-color: #f1f0f0;
        text-align: right;
    }

    .bot-message {
        background-color: #e3f2fd;
    }

    .input-area {
        padding: 10px;
        background-color: #f8f9fa;
    }

    .typing-indicator span {
        height: 10px;
        width: 10px;
        float: left;
        margin: 0 1px;
        background-color: #9E9EA1;
        display: block;
        border-radius: 50%;
        opacity: 0.4;
        animation: 1s blink infinite;
    }

    @keyframes blink {
        50% {
            opacity: 1;
        }
    }
    </style>
</head>

<body>
    <div class="chat-container">
        <div class="chat-header">
            <h2><i class="fas fa-robot me-2"></i>NSUKQUERYBOT</h2>
        </div>
        <div class="chat-messages" id="chatMessages">
            <div class="message bot-message">
                Hello! I'm ready to help. What would you like to know?
            </div>
        </div>
        <div class="input-area">
            <div class="input-group">
                <input type="text" id="userInput" class="form-control" placeholder="Type your message here..."
                    aria-label="User message">
                <button class="btn btn-primary" type="button" id="sendButton">
                    <i class="fas fa-paper-plane"></i> Send
                </button>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script>
    document.addEventListener('DOMContentLoaded', function() {
        const chatMessages = document.getElementById('chatMessages');
        const userInput = document.getElementById('userInput');
        const sendButton = document.getElementById('sendButton');

        function addMessage(message, isUser = false) {
            const messageDiv = document.createElement('div');
            messageDiv.classList.add('message', isUser ? 'user-message' : 'bot-message');
            messageDiv.textContent = message;
            chatMessages.appendChild(messageDiv);
            chatMessages.scrollTop = chatMessages.scrollHeight;
        }

        function addTypingIndicator() {
            const typingDiv = document.createElement('div');
            typingDiv.classList.add('message', 'bot-message', 'typing-indicator');
            typingDiv.innerHTML = '<span></span><span></span><span></span>';
            chatMessages.appendChild(typingDiv);
            chatMessages.scrollTop = chatMessages.scrollHeight;
            return typingDiv;
        }

        async function sendToChatGPT(message) {
            const typingIndicator = addTypingIndicator();
            try {
                const response = await fetch('chatgpt_api.php', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/x-www-form-urlencoded',
                    },
                    body: 'message=' + encodeURIComponent(message)
                });
                const text = await response.text();
                let data;
                try {
                    data = JSON.parse(text);
                } catch (e) {
                    console.error('Error parsing JSON:', text);
                    throw new Error('Invalid JSON response from server');
                }
                typingIndicator.remove();
                if (data.error) {
                    addMessage('Error: ' + data.error);
                } else if (data.response) {
                    addMessage(data.response);
                } else {
                    addMessage('Received an unexpected response from the server.');
                }
            } catch (error) {
                console.error('Error:', error);
                typingIndicator.remove();
                addMessage('Sorry, I encountered an error. Please try again.');
            }
        }

        sendButton.addEventListener('click', function() {
            const message = userInput.value.trim();
            if (message) {
                addMessage(message, true);
                userInput.value = '';
                sendToChatGPT(message);
            }
        });

        userInput.addEventListener('keypress', function(e) {
            if (e.key === 'Enter') {
                sendButton.click();
            }
        });
    });
    </script>
</body>

</html>