<?php
session_start();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $user_message = $_POST['user_message'] ?? '';
    $bot_response = $_POST['bot_response'] ?? '';

    if (!empty($user_message) && !empty($bot_response)) {
        // Add to current chat
        $_SESSION['current_chat'][] = ['sender' => 'user', 'content' => $user_message];
        $_SESSION['current_chat'][] = ['sender' => 'bot', 'content' => $bot_response];

        // Add to chat history
        if (!isset($_SESSION['chat_history'])) {
            $_SESSION['chat_history'] = [];
        }
        $_SESSION['chat_history'][] = [
            'timestamp' => time(),
            'user_message' => $user_message,
            'bot_response' => $bot_response
        ];

        echo json_encode(['status' => 'success']);
    } else {
        echo json_encode(['status' => 'error', 'message' => 'Invalid data']);
    }
} else {
    echo json_encode(['status' => 'error', 'message' => 'Invalid request method']);
}