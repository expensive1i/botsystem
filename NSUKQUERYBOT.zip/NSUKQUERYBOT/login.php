<?php
session_start();
require_once './include/connection.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $username = trim($_POST['username']);
    $password = $_POST['password'];

    $stmt = $conn->prepare("SELECT id, username, password FROM users WHERE username = ?");
    $stmt->bind_param("s", $username);
    $stmt->execute();
    $result = $stmt->get_result();
    
    if ($result->num_rows == 1) {
        $user = $result->fetch_assoc();
        if (password_verify($password, $user['password'])) {
            $_SESSION['user_id'] = $user['id'];
            $_SESSION['username'] = $user['username'];
            header("Location: index.php");
            exit();
        } else {
            $error = "Invalid username or password";
        }
    } else {
        $error = "Invalid username or password";
    }
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login - NSUKQUERYBOT</title>
    <link href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap/5.3.0/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css" rel="stylesheet">
    <style>
    body {
        background: #1a1a2e;
        color: #ffffff;
        font-family: 'Arial', sans-serif;
        min-height: 100vh;
        display: flex;
        align-items: center;
        justify-content: center;
    }

    .login-container {
        background: rgba(255, 255, 255, 0.1);
        border-radius: 10px;
        padding: 40px;
        box-shadow: 0 0 20px rgba(0, 0, 0, 0.2);
        max-width: 400px;
        width: 100%;
    }

    .login-title {
        font-size: 24px;
        margin-bottom: 20px;
        text-align: center;
        color: #4ecca3;
    }

    .form-control {
        background: rgba(255, 255, 255, 0.1);
        border: none;
        border-radius: 20px;
        color: #ffffff;
        padding: 15px 20px;
    }

    .form-control::placeholder {
        color: rgba(255, 255, 255, 0.5);
    }

    .btn-login {
        background: #4ecca3;
        border: none;
        border-radius: 20px;
        color: #1a1a2e;
        font-weight: bold;
        padding: 12px 0;
        transition: all 0.3s ease;
    }

    .btn-login:hover {
        background: #45b293;
        transform: translateY(-2px);
    }

    .robot-icon {
        font-size: 60px;
        margin-bottom: 20px;
        text-align: center;
        color: #4ecca3;
    }

    .typing-animation::after {
        content: '|';
        animation: blink 0.7s infinite;
    }

    @keyframes blink {
        0% {
            opacity: 0;
        }

        50% {
            opacity: 1;
        }

        100% {
            opacity: 0;
        }
    }
    </style>
</head>

<body>
    <div class="login-container">
        <div class="robot-icon">
            <i class="fas fa-robot"></i>
        </div>
        <h2 class="login-title typing-animation" id="loginTitle">NSUKQUERYBOT Login</h2>
        <?php if (isset($error)): ?>
        <div class="alert alert-danger"><?php echo $error; ?></div>
        <?php endif; ?>
        <?php if (isset($_SESSION['message'])): ?>
        <div class="alert alert-success"><?php echo $_SESSION['message']; unset($_SESSION['message']); ?></div>
        <?php endif; ?>
        <form action="login.php" method="post">
            <div class="mb-3">
                <input type="text" class="form-control" id="username" name="username" placeholder="Username" required>
            </div>
            <div class="mb-3">
                <input type="password" class="form-control" id="password" name="password" placeholder="Password"
                    required>
            </div>
            <button type="submit" class="btn btn-login w-100">Login</button>
        </form>
        <p class="mt-3 text-center">Don't have an account? <a href="register.php" class="text-info">Register here</a>
        </p>
    </div>

    <script>
    const loginTitle = document.getElementById('loginTitle');
    const text = loginTitle.textContent;
    loginTitle.textContent = '';
    let i = 0;

    function typeWriter() {
        if (i < text.length) {
            loginTitle.textContent += text.charAt(i);
            i++;
            setTimeout(typeWriter, 100);
        }
    }

    typeWriter();
    </script>
</body>

</html>