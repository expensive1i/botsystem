// Load the FAQ data
const faqData = {
    "faq": [
        // ... your FAQ data here ...
 
              {
                "question": "What is the mission of Nasarawa State University?",
                "answer": "The mission of Nasarawa State University is to provide quality education, foster research, and engage in community development."
              },
              {
                "question": "Where is Nasarawa State University located?",
                "answer": "Nasarawa State University is located in Keffi, Nasarawa State, Nigeria."
              },
              {
                "question": "What is the university’s motto?",
                "answer": "The university's motto is 'Knowledge, Truth, and Service.'"
              },
              {
                "question": "Is there a student support center at the university?",
                "answer": "Yes, the university has a student support center that provides academic and personal counseling."
              },
              {
                "question": "What is the admission process for postgraduate programs?",
                "answer": "The admission process for postgraduate programs involves submitting an online application, academic transcripts, and other required documents."
              },
              {
                "question": "How long does a typical undergraduate program last?",
                "answer": "A typical undergraduate program at Nasarawa State University lasts four years, depending on the course of study."
              },
              {
                "question": "Are there any part-time programs available?",
                "answer": "Yes, the university offers part-time degree programs for working professionals."
              },
              {
                "question": "What are the tuition fees for undergraduate students?",
                "answer": "Tuition fees vary by program. It’s best to check the university’s official website for specific amounts."
              },
              {
                "question": "Does the university offer distance learning programs?",
                "answer": "Yes, Nasarawa State University provides distance learning programs for certain courses."
              },
              {
                "question": "Are there accommodation facilities for students?",
                "answer": "Yes, the university has hostel facilities available for both male and female students."
              },
              {
                "question": "What are the university's rules regarding attendance?",
                "answer": "Students are expected to maintain at least 75% attendance in all classes to be eligible for examinations."
              },
              {
                "question": "Does the university have a library?",
                "answer": "Yes, Nasarawa State University has a well-equipped library with a wide range of academic resources."
              },
              {
                "question": "What are the requirements for international students?",
                "answer": "International students must have equivalent qualifications and meet specific language proficiency requirements."
              },
              {
                "question": "Are there student organizations or clubs?",
                "answer": "Yes, the university has various student organizations and clubs covering academic, cultural, and social interests."
              },
              {
                "question": "How can I access the university's online resources?",
                "answer": "Students can access online resources through the university’s library portal using their student login credentials."
              },
              {
                "question": "What sports are available for students?",
                "answer": "The university offers various sports, including football, basketball, volleyball, and athletics."
              },
              {
                "question": "Is there a career services department?",
                "answer": "Yes, the university has a career services department that helps students with job placements and internships."
              },
              {
                "question": "How can I contact the admissions office?",
                "answer": "You can contact the admissions office through the contact information provided on the university's official website."
              },
              {
                "question": "Are there any exchange programs available?",
                "answer": "Yes, Nasarawa State University has partnerships with several institutions for student exchange programs."
              },
              {
                "question": "What is the university's policy on academic integrity?",
                "answer": "The university maintains a strict policy on academic integrity, and violations such as plagiarism are taken seriously."
              },
              {
                "question": "Is there a health center on campus?",
                "answer": "Yes, the university has a health center that provides basic medical services to students."
              },
              {
                "question": "What is the process for changing a course?",
                "answer": "To change a course, students must fill out a course change form and submit it to their department for approval."
              },
              {
                "question": "Does the university offer any online courses?",
                "answer": "Yes, the university offers a selection of online courses as part of its distance learning program."
              },
              {
                "question": "What is the procedure for withdrawing from a course?",
                "answer": "Students wishing to withdraw from a course must submit a withdrawal request to their department within the specified timeframe."
              },
              {
                "question": "Are there any events or seminars held regularly?",
                "answer": "Yes, the university regularly hosts seminars, workshops, and events for students and faculty."
              },
              {
                "question": "How can I find information about my exam timetable?",
                "answer": "Exam timetables are usually posted on the university’s website or communicated through departmental offices."
              },
              {
                "question": "What is the grading system at Nasarawa State University?",
                "answer": "The grading system typically ranges from A (Excellent) to F (Fail), with specific grade point values assigned to each letter grade."
              },
              {
                "question": "Are there any facilities for disabled students?",
                "answer": "Yes, the university is committed to providing facilities and support for students with disabilities."
              },
              {
                "question": "How do I apply for a scholarship?",
                "answer": "To apply for a scholarship, students should check the university's scholarship portal for available opportunities and application guidelines."
              },
              {
                "question": "What are the job prospects for graduates?",
                "answer": "Graduates of Nasarawa State University have diverse job prospects in various sectors, including government, education, and private industries."
              },
              {
                "question": "Is there a dress code for students?",
                "answer": "The university has a dress code policy that promotes professionalism, especially during formal occasions."
              },
              {
                "question": "What language is the medium of instruction?",
                "answer": "The medium of instruction at Nasarawa State University is primarily English."
              },
              {
                "question": "Are there any special programs for first-year students?",
                "answer": "Yes, the university offers orientation programs to help first-year students acclimate to campus life."
              },
              {
                "question": "What kind of research opportunities are available?",
                "answer": "Students can participate in research projects and collaborate with faculty members on various topics."
              },
              {
                "question": "Can I transfer from another university?",
                "answer": "Yes, students can apply for transfer admission, subject to meeting the university’s requirements."
              },
              {
                "question": "What are the library opening hours?",
                "answer": "The library typically operates from 8 AM to 8 PM, but hours may vary during exams and holidays."
              },
              {
                "question": "Are there any mandatory courses for all students?",
                "answer": "Yes, there are general studies courses that all students must take as part of their curriculum."
              },
              {
                "question": "What is the policy on late submission of assignments?",
                "answer": "Late submissions may incur penalties, but students can apply for extensions under certain circumstances."
              },
              {
                "question": "Is there a university newspaper or magazine?",
                "answer": "Yes, the university publishes a student newspaper that covers news, events, and student achievements."
              },
              {
                "question": "How can I get involved in community service?",
                "answer": "Students can join various clubs and organizations focused on community service and outreach programs."
              },
              {
                "question": "What are the benefits of joining student clubs?",
                "answer": "Joining student clubs offers networking opportunities, personal development, and social interaction."
              },
              {
                "question": "Does the university offer IT support for students?",
                "answer": "Yes, there is an IT support center available for students needing assistance with technical issues."
              },
              {
                "question": "What are the graduation requirements?",
                "answer": "To graduate, students must complete all required courses, meet the credit hour requirements, and fulfill any other departmental obligations."
              },
              {
                "question": "How can I access academic transcripts?",
                "answer": "Academic transcripts can be requested from the registrar’s office, usually for a fee."
              },
              {
                "question": "What types of internships are available?",
                "answer": "The university partners with various organizations to provide internships in fields related to students' courses."
              },
              {
                "question": "Is there a university chapel or place of worship?",
                "answer": "Yes, the university has a chapel and designated prayer areas for students of various faiths."
              },
              {
                "question": "What safety measures are in place on campus?",
                "answer": "The university has security personnel and surveillance systems to ensure the safety of students and staff."
              },
              {
                "question": "Are there any environmental initiatives at the university?",
                "answer": "Yes, the university promotes sustainability through various environmental initiatives and programs."
              },
              {
                "question": "How often do faculty members hold office hours?",
                "answer": "Faculty members typically hold office hours weekly, and students can check with their departments for specific times."
              },
              {
                "question": "Can I bring my vehicle to campus?",
                "answer": "Yes, students are allowed to bring vehicles, but they must register for a parking permit."
              }
            
    ]
}
const userInput = document.getElementById('userInput');
const sendButton = document.getElementById('sendButton');
const chatMessages = document.getElementById('chatMessages');
const similarQuestionsModal = new bootstrap.Modal(document.getElementById('similarQuestionsModal'));
const similarQuestionsBody = document.getElementById('similarQuestionsBody');

userInput.addEventListener('input', debounce(showSimilarQuestions, 300));
sendButton.addEventListener('click', sendMessage);
userInput.addEventListener('keypress', function(e) {
    if (e.key === 'Enter') {
        sendMessage();
    }
});

function debounce(func, delay) {
    let debounceTimer;
    return function() {
        const context = this;
        const args = arguments;
        clearTimeout(debounceTimer);
        debounceTimer = setTimeout(() => func.apply(context, args), delay);
    }
}

function showSimilarQuestions() {
    const query = userInput.value.toLowerCase();
    if (query.length < 3) return;

    const similarQuestions = faqData.faq.filter(item => 
        item.question.toLowerCase().includes(query)
    ).slice(0, 5);

    if (similarQuestions.length > 0) {
        similarQuestionsBody.innerHTML = similarQuestions.map(item => 
            `<div class="similar-question" data-question="${item.question}">${item.question}</div>`
        ).join('');

        similarQuestionsBody.querySelectorAll('.similar-question').forEach(div => {
            div.addEventListener('click', function() {
                userInput.value = this.dataset.question;
                similarQuestionsModal.hide();
                sendMessage();
            });
        });

        similarQuestionsModal.show();
    }
}

function sendMessage() {
    const message = userInput.value.trim();
    if (message) {
        addMessage('user', message);
        userInput.value = '';
        similarQuestionsModal.hide();

        // Simulate bot typing
        addMessage('bot', '<div class="typing-indicator"><span></span><span></span><span></span></div>');

        // Find the answer in the FAQ data
        const faqItem = faqData.faq.find(item => item.question.toLowerCase() === message.toLowerCase());

        // Simulate delay and then show the answer
        setTimeout(() => {
            // Remove typing indicator
            chatMessages.removeChild(chatMessages.lastElementChild);

            if (faqItem) {
                addMessage('bot', faqItem.answer);
            } else {
                addMessage('bot', "I'm sorry, I don't have an answer for that question. Can you please rephrase or ask something else?");
            }
        }, 4000);
    }
}

function addMessage(sender, content) {
    const messageDiv = document.createElement('div');
    messageDiv.classList.add('message', `${sender}-message`);
    messageDiv.innerHTML = content;
    chatMessages.appendChild(messageDiv);
    chatMessages.scrollTop = chatMessages.scrollHeight;
}