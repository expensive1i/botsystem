<?php
session_start();
include './include/connection.php';
include './include/header.php';

// Check if user is logged in
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

// Fetch username from database
$user_id = $_SESSION['user_id'];
$stmt = $conn->prepare("SELECT username FROM users WHERE id = ?");
$stmt->bind_param("i", $user_id);
$stmt->execute();
$result = $stmt->get_result();
$user = $result->fetch_assoc();
$username = $user['username'];

// Initialize chat history if not exists
if (!isset($_SESSION['chat_history'])) {
    $_SESSION['chat_history'] = [];
}

// Handle new chat request
if (isset($_GET['new_chat'])) {
    $_SESSION['current_chat'] = [];
    header('Location: index.php');
    exit;
}

// Load FAQ data
$faqData = json_decode(file_get_contents('faq.json'), true)['faq'];
usort($faqData, function ($a, $b) {
    return strcmp($a['question'], $b['question']);
});
?>


<body>
    <div class="wrapper">

        <?php
        include './include/sidebar.php'
        ?>
        <div class="content">
            <div class="welcome-section">
                <div class="welcome-message">
                    <h1>Welcome back, <span class="user-name"><?php echo htmlspecialchars($username); ?></span></h1>
                </div>
            </div>
            <div class="chat-container">
                <div class="chat-header">
                    <h2><i class="fas fa-robot me-2"></i>NSUKQUERYBOT</h2>
                </div>
                <div class="chat-messages" id="chatMessages">
                    <?php
                    if (!empty($_SESSION['current_chat'])) {
                        foreach ($_SESSION['current_chat'] as $message) {
                            echo "<div class='message {$message['sender']}-message'>{$message['content']}</div>";
                        }
                    } else {
                        echo "<div class='message bot-message'>Hello " . htmlspecialchars($username) . "! I'm your AI assistant. How can I help you today?</div>";
                    }
                    ?>
                </div>
                <div class="input-area">
                    <div class="input-group">
                        <input type="text" id="userInput" class="form-control" placeholder="Ask me anything..."
                            aria-label="User question">
                        <button class="btn btn-send" type="button" id="sendButton">
                            <i class="fas fa-paper-plane"></i>
                        </button>
                    </div>
                    <div class="suggestions" id="suggestions"></div>
                </div>
            </div>
        </div>
    </div>

    <script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap/5.3.0/js/bootstrap.bundle.min.js"></script>
    <script>
    let faqData = <?php echo json_encode($faqData); ?>;

    const userInput = document.getElementById('userInput');
    const sendButton = document.getElementById('sendButton');
    const chatMessages = document.getElementById('chatMessages');
    const suggestions = document.getElementById('suggestions');

    userInput.addEventListener('input', showSuggestions);
    sendButton.addEventListener('click', sendMessage);
    userInput.addEventListener('keypress', function(e) {
        if (e.key === 'Enter') {
            sendMessage();
        }
    });

    function showSuggestions() {
        const query = userInput.value.toLowerCase();
        if (query.length === 0) {
            suggestions.innerHTML = '';
            return;
        }

        const matchingQuestions = faqData.filter(item =>
            item.question.toLowerCase().includes(query)
        ).slice(0, 5);

        if (matchingQuestions.length > 0) {
            suggestions.innerHTML = matchingQuestions.map(item =>
                `<div class="suggestion-item"><i class="fas fa-search"></i>${item.question}</div>`
            ).join('');

            suggestions.querySelectorAll('.suggestion-item').forEach(div => {
                div.addEventListener('click', function() {
                    userInput.value = this.textContent.trim();
                    suggestions.innerHTML = '';
                    sendMessage();
                });
            });
        } else {
            suggestions.innerHTML = '';
        }
    }

    function sendMessage() {
        const message = userInput.value.trim();
        if (message) {
            addMessage('user', message);
            userInput.value = '';
            suggestions.innerHTML = '';

            // Simulate bot typing
            addMessage('bot', '<div class="typing-indicator"><span></span><span></span><span></span></div>');

            // Find the answer in the FAQ data
            const faqItem = faqData.find(item => item.question.toLowerCase() === message.toLowerCase());

            // Simulate delay and then show the answer
            setTimeout(() => {
                // Remove typing indicator
                chatMessages.removeChild(chatMessages.lastElementChild);

                let botResponse;
                if (faqItem) {
                    botResponse = faqItem.answer;
                } else {
                    botResponse =
                        "I'm sorry, I don't have information on this at the moment. Can you please ask another question?";
                }

                addMessage('bot', botResponse);

                // Save to session via AJAX
                fetch('save_chat.php', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/x-www-form-urlencoded',
                    },
                    body: `user_message=${encodeURIComponent(message)}&bot_response=${encodeURIComponent(botResponse)}`
                });
            }, 1000);
        }
    }

    function addMessage(sender, content) {
        const messageDiv = document.createElement('div');
        messageDiv.classList.add('message', `${sender}-message`);
        messageDiv.innerHTML = content;
        chatMessages.appendChild(messageDiv);
        chatMessages.scrollTop = chatMessages.scrollHeight;
    }

    // Sidebar toggle functionality
    document.addEventListener('DOMContentLoaded', function() {
        var sidebarCollapse = document.getElementById('sidebarCollapse');
        var sidebar = document.getElementById('sidebar');

        sidebarCollapse.addEventListener('click', function() {
            sidebar.classList.toggle('active');
        });
    });
    </script>
</body>

</html>