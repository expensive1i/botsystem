<?php
session_start();
include './include/header.php';
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Query History - NSUKQUERYBOT</title>
    <link href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap/5.3.0/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css" rel="stylesheet">
    <style>
    /* Add any additional styles here */
    .query-item {
        border-bottom: 1px solid #eee;
        padding: 15px 0;
    }

    .query-item:last-child {
        border-bottom: none;
    }

    .timestamp {
        font-size: 0.8em;
        color: #888;
    }
    </style>
</head>

<body>
    <div class="wrapper">
        <?php include './include/sidebar.php'; ?>
        <div class="content">
            <button type="button" id="sidebarCollapse" class="d-md-none">
                <i class="fas fa-bars"></i>
            </button>
            <div class="container mt-4">
                <h2>Query History</h2>
                <div class="query-list">
                    <?php
                    if (isset($_SESSION['chat_history']) && !empty($_SESSION['chat_history'])) {
                        foreach (array_reverse($_SESSION['chat_history']) as $query) {
                            echo "<div class='query-item'>";
                            echo "<p class='timestamp'>" . date('Y-m-d H:i:s', $query['timestamp']) . "</p>";
                            echo "<p><strong>You:</strong> " . htmlspecialchars($query['user_message']) . "</p>";
                            echo "<p><strong>Bot:</strong> " . htmlspecialchars($query['bot_response']) . "</p>";
                            echo "</div>";
                        }
                    } else {
                        echo "<p>No query history available.</p>";
                    }
                    ?>
                </div>
            </div>
        </div>
    </div>

    <script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap/5.3.0/js/bootstrap.bundle.min.js"></script>
    <script>
    // Sidebar toggle functionality
    document.addEventListener('DOMContentLoaded', function() {
        var sidebarCollapse = document.getElementById('sidebarCollapse');
        var sidebar = document.getElementById('sidebar');

        sidebarCollapse.addEventListener('click', function() {
            sidebar.classList.toggle('active');
        });
    });
    </script>
</body>

</html>