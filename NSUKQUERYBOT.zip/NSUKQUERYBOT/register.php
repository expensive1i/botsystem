<?php
session_start();
require_once './include/connection.php';

$registration_success = false;

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $username = trim($_POST['username']);
    $email = trim($_POST['email']);
    $password = $_POST['password'];

    // Basic validation
    if (empty($username) || empty($email) || empty($password)) {
        $error = "All fields are required";
    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $error = "Invalid email format";
    } else {
        // Check if username or email already exists
        $stmt = $conn->prepare("SELECT id FROM users WHERE username = ? OR email = ?");
        $stmt->bind_param("ss", $username, $email);
        $stmt->execute();
        $result = $stmt->get_result();
        
        if ($result->num_rows > 0) {
            $error = "Username or email already exists";
        } else {
            // Insert new user
            $hashed_password = password_hash($password, PASSWORD_DEFAULT);
            $stmt = $conn->prepare("INSERT INTO users (username, email, password) VALUES (?, ?, ?)");
            $stmt->bind_param("sss", $username, $email, $hashed_password);
            
            if ($stmt->execute()) {
                $registration_success = true;
            } else {
                $error = "Registration failed. Please try again.";
            }
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Register - NSUKQUERYBOT</title>
    <link href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap/5.3.0/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css" rel="stylesheet">
    <style>
    body {
        background: #1a1a2e;
        color: #ffffff;
        font-family: 'Arial', sans-serif;
        min-height: 100vh;
        display: flex;
        align-items: center;
        justify-content: center;
    }

    .register-container {
        background: rgba(255, 255, 255, 0.1);
        border-radius: 10px;
        padding: 40px;
        box-shadow: 0 0 20px rgba(0, 0, 0, 0.2);
        max-width: 400px;
        width: 100%;
    }

    .register-title {
        font-size: 24px;
        margin-bottom: 20px;
        text-align: center;
        color: #4ecca3;
    }

    .form-control {
        background: rgba(255, 255, 255, 0.1);
        border: none;
        border-radius: 20px;
        color: #ffffff;
        padding: 15px 20px;
    }

    .form-control::placeholder {
        color: rgba(255, 255, 255, 0.5);
    }

    .btn-register {
        background: #4ecca3;
        border: none;
        border-radius: 20px;
        color: #1a1a2e;
        font-weight: bold;
        padding: 12px 0;
        transition: all 0.3s ease;
    }

    .btn-register:hover {
        background: #45b293;
        transform: translateY(-2px);
    }

    .robot-icon {
        font-size: 60px;
        margin-bottom: 20px;
        text-align: center;
        color: #4ecca3;
    }

    .typing-animation::after {
        content: '|';
        animation: blink 0.7s infinite;
    }

    @keyframes blink {
        0% {
            opacity: 0;
        }

        50% {
            opacity: 1;
        }

        100% {
            opacity: 0;
        }
    }

    #successAnimation {
        position: fixed;
        top: 0;
        left: 0;
        width: 100%;
        height: 100%;
        background: rgba(0, 0, 0, 0.8);
        display: flex;
        justify-content: center;
        align-items: center;
        flex-direction: column;
        z-index: 1000;
    }

    .dancing-robot {
        font-size: 100px;
        color: #4ecca3;
        animation: dance 1s infinite alternate;
    }

    @keyframes dance {
        0% {
            transform: translateY(0) rotate(0deg);
        }

        100% {
            transform: translateY(-20px) rotate(10deg);
        }
    }
    </style>
</head>

<body>
    <div class="register-container">
        <div class="robot-icon">
            <i class="fas fa-robot"></i>
        </div>
        <h2 class="register-title typing-animation" id="registerTitle">NSUKQUERYBOT Register</h2>
        <?php if (isset($error)): ?>
        <div class="alert alert-danger"><?php echo $error; ?></div>
        <?php endif; ?>
        <form action="register.php" method="post">
            <div class="mb-3">
                <input type="text" class="form-control" id="username" name="username" placeholder="Username" required>
            </div>
            <div class="mb-3">
                <input type="email" class="form-control" id="email" name="email" placeholder="Email" required>
            </div>
            <div class="mb-3">
                <input type="password" class="form-control" id="password" name="password" placeholder="Password"
                    required>
            </div>
            <button type="submit" class="btn btn-register w-100">Register</button>
        </form>
        <p class="mt-3 text-center">Already have an account? <a href="login.php" class="text-info">Login here</a></p>
    </div>

    <?php if ($registration_success): ?>
    <div id="successAnimation">
        <div class="dancing-robot">
            <i class="fas fa-robot"></i>
        </div>
        <h2 class="mt-4 text-white">Welcome aboard!</h2>
    </div>
    <?php endif; ?>

    <script>
    const registerTitle = document.getElementById('registerTitle');
    const text = registerTitle.textContent;
    registerTitle.textContent = '';
    let i = 0;

    function typeWriter() {
        if (i < text.length) {
            registerTitle.textContent += text.charAt(i);
            i++;
            setTimeout(typeWriter, 100);
        }
    }

    typeWriter();

    <?php if ($registration_success): ?>
    setTimeout(() => {
        document.getElementById('successAnimation').style.display = 'none';
        window.location.href = 'login.php';
    }, 3000);
    <?php endif; ?>
    </script>
</body>

</html>