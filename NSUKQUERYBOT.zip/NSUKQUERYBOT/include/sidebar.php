<nav id="sidebar" class="sidebar">
    <div class="sidebar-header">
        <h3>NSUKQUERYBOT</h3>
    </div>
    <ul class="sidebar-menu list-unstyled">
        <li>
            <a href="index.php?new_chat=1"><i class="fas fa-plus"></i> New Chat</a>
        </li>
        <li>
            <a href="index.php"
                <?php echo (basename($_SERVER['PHP_SELF']) == 'index.php' && !isset($_GET['new_chat'])) ? 'class="active"' : ''; ?>>
                <i class="fas fa-comment"></i> Chat
            </a>
        </li>
        <li>
            <a href="query_history.php"
                <?php echo (basename($_SERVER['PHP_SELF']) == 'query_history.php') ? 'class="active"' : ''; ?>>
                <i class="fas fa-history"></i> Query History
            </a>
        </li>
        <li>
            <a href="support.php"
                <?php echo (basename($_SERVER['PHP_SELF']) == 'support.php') ? 'class="active"' : ''; ?>>
                <i class="fas fa-headset"></i> Help & Support
            </a>
        </li>
    </ul>
    <div class="robot-animation">
        <div class="robot">
            <i class="fas fa-robot"></i>
        </div>
    </div>
    <div class="mt-auto p-3">
        <a href="login.php" class="btn btn-outline-danger w-100"><i class="fas fa-sign-out-alt"></i> Logout</a>
    </div>
</nav>